
#! /bin/bash
start_message()
{
   echo "FILE EMPTY"
   exit 1
}
echo "Pinging IP range"

IPRANGE=`cat svrList.txt`

# echo $IPRANGE

if [ "$IPRANGE" == "" ]; then
   echo "Wrong argument: $1"
   start_message
fi

# echo "Connect this IP range and port: $IPRANGE"

# LOOP IP in TXT 
for ipPort in $IPRANGE; 
do
   IPADDR=$ipPort

# Red print
# echo "$(tput setaf 3) http://$IPADDR $(tput setaf 7)"
echo "$(tput setaf 7) Scanning ... $IPADDR "

   RESULT=$(curl -IS -s --connect-timeout 3 --max-time 3 $IPADDR )

   if [ "$RESULT" != "" ]; then
      echo "$(tput setaf 2)$IPADDR ESTABLISHED $(tput setaf 7)"
   else
      echo "$(tput setaf 1)$IPADDR FAIL $(tput setaf 7)"
   fi

done


# https://reactgo.com/bash-change-terminal-color/
# https://ladydebug.com/blog/2020/03/12/curl-for-port-scanning/
# https://stackoverflow.com/questions/14093452/grep-only-the-first-match-and-stop
# https://catonmat.net/cookbooks/curl/make-curl-silent
# curl -IS -s --connect-timeout 3 --max-time 5 http://192.168.0.196:139
# curl -IS -s --connect-timeout 3 --max-time 5 223.130.195.95

