

#! /bin/bash
start_message()
{
   echo "Correct argument required, IP range and port"
   echo "Example: 192.168.1.0-127:1234"
   exit 1
}
echo "Pinging IP range"

if [ $# -eq 0 ]; then
   start_message
fi

IPRANGE=$(echo $1 | grep -v '[A-Za-z]' | grep -oE '(\b[0-9]{1,3}\.){3}[0-9]{1,3}-[0-9]{1,3}:[0-9]{1,5}')

echo $IPRANGE

if [ "$IPRANGE" == "" ]; then
   echo "Wrong argument: $1"
   start_message
fi

echo "Connect this IP range and port: $IPRANGE"

IPBASE=$(echo $IPRANGE | grep -oE '(\b[0-9]{1,3}\.){2}[0-9]{1,3}')
echo $IPBASE

IPSTART=$(echo $IPRANGE | grep -oE '\b[0-9]{1,3}-' | grep -oE '\b[0-9]{1,3}')
echo $IPSTART

IPEND=$(echo $IPRANGE | grep -oE '\b-[0-9]{1,3}' | grep -oE '\b[0-9]{1,3}')
echo $IPEND

PORT=$(echo $IPRANGE | grep -oE '\b:[0-9]{1,5}' | grep -oE '\b[0-9]{1,5}')

echo $PORT
for param in `seq $IPSTART $IPEND`; do
   IPADDR=$IPBASE.$param

# Red print
echo "$(tput setaf 7)$IPADDR:$PORT"

   RESULT=$(curl -I --connect-timeout 3 --max-time 3 http://$IPADDR:$PORT )

   if [ "$RESULT" != "" ]; then
      echo "$(tput setaf 2)$IPADDR. Listening on port $PORT $(tput setaf 7)"
   fi

done

