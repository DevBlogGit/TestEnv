
#! /bin/bash
start_message()
{
   echo "Correct argument required, IP range and port"
   echo "Example: 192.168.1.0-127:1234"
   exit 1
}
echo "Pinging IP range"

if [ $# -eq 0 ]; then
   start_message
fi

# IPRANGE=$(echo $1 | grep -v '[A-Za-z]' | grep -oE '(\b[0-9]{1,3}\.){3}[0-9]{1,3}-[0-9]{1,3}:[0-9]{1,5}')

PORTRANGE="echo $1 | grep -v '[A-Za-z]' | grep -oE '(\b[0-9]{1,3}\.){3}[0-9]{1,3}:[0-9]{1,5}-[0-9]{1,5}'"

echo $PORTRANGE

if [ "$PORTRANGE" == "" ]; then
   echo "Wrong argument: $1"
   start_message
fi

echo "Connect this IP range and port: $IPRANGE"

#IPBASE=$(echo $IPRANGE | grep -oE '(\b[0-9]{1,3}\.){2}[0-9]{1,3}')
#echo $IPBASE

PORTBASE=$(echo $PORTRANGE | grep -oE '(\b[0-9]{1,3}\.){3}[0-9]{1,3}')
echo $PORTBASE

# IPRANGE START - END
#IPSTART=$(echo $IPRANGE | grep -oE '\b[0-9]{1,3}-' | grep -oE '\b[0-9]{1,3}')
#echo $IPSTART
#IPEND=$(echo $IPRANGE | grep -oE '\b-[0-9]{1,3}' | grep -oE '\b[0-9]{1,3}')
#echo $IPEND


# PORTRANGE START - END
PORT=$(echo $IPRANGE | grep -oE '\b:[0-9]{1,5}' | grep -oE '\b[0-9]{1,5}')
PORTSTART=$(echo $PORTRANGE | grep -oE '\b:[0-9]{1,5}-' | grep -oE '\b[0-9]{1,5}')
PORTEND=$(echo $PORTRANGE | grep -oE '\b-[0-9]{1,5}' | grep -m 1 -oE '\b[0-9]{1,5}' )

echo $PORT

# LOOP PORTRANGE
for param in `seq $PORTSTART $PORTEND`; do
   IPADDR=$PORTBASE:$param

# Red print
echo "http://$(tput setaf 7)$IPADDR"

   RESULT=$(curl -IS -s -o --connect-timeout 3 --max-time 3 http://$IPADDR )

   if [ "$RESULT" != "" ]; then
      echo "$(tput setaf 2)$IPADDR. Listening on port $(tput setaf 7)"
   fi

done


# https://reactgo.com/bash-change-terminal-color/
# https://ladydebug.com/blog/2020/03/12/curl-for-port-scanning/
# https://stackoverflow.com/questions/14093452/grep-only-the-first-match-and-stop
# https://catonmat.net/cookbooks/curl/make-curl-silent

